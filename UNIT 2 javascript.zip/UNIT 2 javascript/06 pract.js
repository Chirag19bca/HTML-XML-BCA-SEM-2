function validate() {
    //function validation//
    var fullname = document.getElementById("fname").value;
    // var len =fullname.length;
    //alert(fullname);
    if (fullname == "") {
        //alert("Please Enter Full Name")
        document.getElementById("msg1").innerHTML = "Please Enter First Name";
        document.getElementById("fname").style.outlineColor = "red";
        document.getElementById("msg1").style.fontSize = "1px";
        document.getElementById("fname").focus();
        return false;
    } else {
        document.getElementById("msg1").innerHTML = "done";
    }
    //pincode validation
    var pin = document.getElementById("pin").value;
    var pinpattern = /^[0-9]{6}$/;
    if (!pinpattern.test(pin)) {
        document.getElementById("msgpin").innerHTML =
            "Please Enter Valid pincode no";
        return false;
    } else {
        document.getElementById("msgpin").innerHTML = "done";
    }
    //last name validation//
    var lnm = document.getElementById("lname").value;
    if (lnm == "") {
        document.getElementById("msglnm").innerHTML = "Please Enter Last Name";
        return false;
    } else {
        document.getElementById("msglnm").innerHTML = "";
    }
    //Contact Validation//
    var pattern = /^[\+][0-9\s]{3}[0-9\s]{6}[0-9]{5}$/;
    var contactno = document.getElementById("cno").value;
    if (!pattern.test(contactno)) {
        document.getElementById("msg2").innerHTML = "Please Enter Proper Contactno";
        document.getElementById("cno").style.outlineColor = "red";
        document.getElementById("cno").focus();
        return false;
    } else {
        document.getElementById("msg2").innerHTML = "";
    }
    /*var len=Contactno.length;
      alert(len);
      alert(Contactno);
      if(len==0)
      {
          document.getElementById('msg2).innerHTML="Please Enter Contactno";
          document.getElementById('cno').style.outlineColor="red";
          document.getElementById('cno').focus();
          return false;
      }*/
    /*if(Contactno=="")
      {
          //alert("Please Enter Contactno")
          document.getElementById('msg2').innerHTML="Please Enter Contactno";
          document.getElementById('cno').style.outlineColor="red";
          document.getElementById('cno').focus();
          return false;
      }
      //var len=Contactno.length
      //if(ln<10||len>=11)
      if(len==10)
      {
          document.getElementById('msg2').innerHTML="";
      }
      else
      {
          document.getElementById('msg2').innerHTML="Please Enter Ten Digit Number";
          document.getElementById('cno').style.outlineColor="red";
          document.getElementById('cno').focus();
          return false;

      }
      if(!Number(Contactno))
      {
          //alert("Please Enter Numeric Value Only")
          document.getElementById('msg2').innerHTML="Please Enter Numeric Value Only";
          document.getElementById('cno').style.outlineColor="red";
          document.getElementById('cno').focus();
          return false;
      }*/
    //Email Validation
    var emailpattern = /^[a-zA-Z0-9_]+@[a-z]+\.[a-z]{2,4}$/;
    var emailID = document.getElementById("email").value;
    if (!emailpattern.test(emailID)) {
        document.getElementById("msg3").innerHTML = "Please Enter Correct email ID";
        document.getElementById("email").style.outlineColor = "green";
        document.getElementById("email").focus();
        return false;
    } else {
        document.getElementById("msg3").innerHTML = "";
    }
    /* var atpos = emailID.indexOf("@");
       //alert(atpos);
    var dotpos = emailID.indexOf(".");
       //alert(dotpos);
    if (atpos < 1 || (dotpos - atpos < 2))
    {
        document.getElementById('msg3').innerHTML = "Please Enter Correct email ID";
        document.getElementById('email').style.outlineColor = "green";
        document.getElementById('email').focus();
        return false;
    } else {
        document.getElementById('msg3').innerHTML = "";
    }*/
    //radio validation
    var gr = document.getElementsByName("g");
    //alert(gr);
    var lan = gr.length;
    //alert(lan);
    var cnt = 0;
    var i;
    /*alert("counter"+cnt);
    alert("lan"+lan);*/
    for (i = 0; i < lan; i++) {
        //alert("counter"+cnt);
        if (gr[i].checked == true) {
            //alert("counter"+cnt);
            // var g=gr[i].value;
            // alert(g);
            document.getElementById("msg4").innerHTML = "";
            cnt = 1;
            // alert(cnt);
            break;
        }
    }
    if (cnt == 0) {
        //alert("counter"+cnt);
        document.getElementById("msg4").innerHTML =
            "Please select atleast one gender";
        return false;
    }
    //checkbox validation
    var ch = document.getElementsByName("c");
    // alert(ch);//stop;
    var len = ch.length;
    var cnt = 0;
    //alert("length of button"+ len);
    for (i = 0; i < len; i++) {
        //alert("counter"+ cnt);
        if (ch[i].checked == true) {
            /*alert("counter"+ cnt);
                var val=new Array();
                val[i]=ch[i].value;
                alert(val[i]);*/
            document.getElementById("msg5").innerHTML = "";
            cnt = 1;
            /* alert("counter"+ cnt);
                break;*/
        }
    }
    if (cnt == 0) {
        //alert("counter"+cnt);
        document.getElementById("msg5").innerHTML =
            "Please select atleast one option";
        return false;
    }
    //combobox validation
    var sel = document.getElementById("clr").value;
    //alert(sel);
    if (sel == "") {
        document.getElementById("ms6").innerHTML =
            "Please select atleast one option";
        return false;
    } else {
        document.getElementById("msg6").innerHTML = "";
    }
    // multiple selection in listbox validation
    // combobox validation
    var sel = document.getElementById("v").value;
    //alert(sel);
    if (sel == "") {
        document.getElementById("msg7").innerHTML =
            "Please select atleast one option";
        return false;
    } else {
        document.getElementById("msg7").innerHTML = "";
    }
    //Date validation
    var db = document.getElementById("db").value;
    // alert(db);
    var date = new Date();
    var dd = date.getDate();
    // alert(dd);
    var mm = date.getMonth() + 1;
    // alert(mm);
    var yy = date.getFullYear();
    // alert(yy);
    if (dd <= 9) {
        dd = "0" + dd;
    }
    if (mm <= 9) {
        mm = "0" + mm;
    }
    var db2 = yy + "_" + mm + "_" + dd;
    // alert(db2);
    if (db == "") {
        document.getElementById("msg8").innerHTML = "Please Enter Date of birth";
        document.getElementById("db").style.outlineColor = "red";
        document.getElementById("msg8").style.fontSize = "1px";
        document.getElementById("db").focus();
        return false;
    }
    //alert(db+"#####"+db2);
    if (db > db2) {
        document.getElementById("msg8").innerHTML =
            "Date of Birth is not greater then Current Date";
        document.getElementById("db").style.outlineColor = "red";
        document.getElementById("msg8").style.fontSize = "1px";
        document.getElementById("db").focus();
        return false;
    } else {
        document.getElementById("msg8").innerHTML = "";
    }
    //range validation
    var age = document.getElementById("rg").value;
    // alert(age);
    if (age == 0) {
        document.getElementById("msg9").innerHTML =
            "Your Age must be Greater then Zero";
        return false;
    } else {
        document.getElementById("msg9").innerHTML = "";
    }
}

function getval() {
    var age = document.getElementById("rg").value;
    document.getElementById("ans").innerHTML = age;
}

function can() {
    window.open("practical 06 js.html");
}